'''
List is mutable
 __ we can add new data to an existing list
            =======
             |->Listname.append(Value) ->None
             |->Listname.insert(index,Value) ->None
             
 __ we can modify an existing value from list  --->ListName[OldIndex]=UpdatedValue
 __ we can delete nth item from an existing list
            --------------
                    |-> Listname.pop() ->removed_value default last index value
                    |      Vs
                    |-> Listname.pop(index) ->remove nth index value
         
'''
L=[] # empty list
print(f"No.of items:{len(L)}")

L.append(45)
L.append(98.34)
L.append('data')
L.append(True)
print(f"No.of items:{len(L)}")
print(L)

L1=[10,20,30,40,50,60]
r = L1.pop() # remove last index value
print(f"removed value:{r}")
print(L1)
r = L1.pop(2) # remove 2nd index value
print(f"removed value:{r}")
print(L1)

