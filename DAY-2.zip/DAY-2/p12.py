'''
File write operation
Author: Karthik
Version: 3.12
'''
wobj = open('E:\\Demo1\\r1.log','w')
cost=12323.23
wobj.write("Data1\n")
wobj.write(str(cost))
wobj.write("data1"+"data2"+"data3"+"data4\n")
wobj.write("result="+str(10+20/3)+"\n")
wobj.write("prodID"+","+"Pname"+","+"Pcost\n")
wobj.close()
