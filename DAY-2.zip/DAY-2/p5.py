
T=('D1',10,1.34,True)

print(type(T),len(T))

for var in T:
    print(var)

print(T[-3:])

if('D1' in T):
    print('yes - exists')
else:
    print('Not exists')

v1,v2,v3,v4 = T

T[1]='data' # Error - tuple is immutable
