print('This is main section-1')

def f1():
    print('List of files:-')
    for var in ['F1','F2','F3']:
        print(var,end=' ')
    print('Exit from f1 block')

def f2():
    print('display mounted filesystems')
    print('Exit from f2 block')

f1()
print('')
f2()
print('')
f1()
print('Exit from main script')
