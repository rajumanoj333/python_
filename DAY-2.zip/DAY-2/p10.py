PIN=1234
def pin_test(pin):
    if(pin == PIN):
        return True
    else:
        return False

c=0
while(c<3):
    c=c+1
    p = int(input('Enter a pinNumber:'))
    if(pin_test(p)):
        print(f'Success - pin is matched {c}')
        break

if(int(p) != PIN):
    print('Sorry your pin is blocked')
