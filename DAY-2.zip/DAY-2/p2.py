s='python'
print(type(s),len(s))
print(s[0],s[1],s[-1])
print(s[-3:])

for var in s:
    print(var)
print('')

L=['D1','D2','D3',10,20.34,True,'Data']
print(type(L),len(L))
print(L[0],L[1],L[-1])
print(L[-3:])

for var in L:
    print(var)

L[1]= 450 # we can modify an existing value
          # list is mutable
print(L)
#s[1]= "X" # Error - str is immutable
