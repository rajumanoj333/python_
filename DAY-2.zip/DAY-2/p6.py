hosts = {} # empty dict
c=0
while(c<3):
    c=c+1
    h = input('Enter a hostname:')
    ip = input(f'Enter {h} IPAddress:')
    hosts[h]=ip # adding new data to an existing dict

print('\nHostname\t IPAddress:')
# display key(host) - value(IPAddress)
for var in hosts:
    print(f'{var} {hosts[var]}')

var_host = input('Enter a hostname:') # reading hostname from <STDIN>

if(var_host in hosts): # test input host is existing or not
    hosts[var_host]='127.0.0.1' # update 
else:
    hosts[var_host]='127.0.0.1' # adding new data
    
print('\n updated host - IPAddress')
for var in hosts:
    print(f'{var} {hosts[var]}')
