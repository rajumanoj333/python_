fname = 'index.html'
findex = 1234
futil = 98.2
fstatus = True

Finfo = [fname,findex,futil,fstatus]

print(type(Finfo))
print(f'No.of items:{len(Finfo)}')

print(type(Finfo[0]),type(Finfo[1]),type(Finfo[2]))
print(type(Finfo[3]))
