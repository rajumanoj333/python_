hosts = [] # empty list

c=0
while(c <5):
	h = input('Enter a hostname:')
	hosts.append(h) # appending input host to an existing list
	c=c+1

print("List of host details:-")
print("-"*50)
for var in hosts:
	print(var)

print(f"Total no.of hosts:{len(hosts)}")
