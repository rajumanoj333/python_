'''

EMP=['101,raj,sales,Pune,1000','102,bibu,prod,bglore,2000',
     '103,leo,sales,Mumbai,3000','104,anu,Hr,hyderabad,4000']
'''

EMP=['101,raj,sales,Pune,1000','102,bibu,prod,bglore,2000','103,leo,sales,Mumbai,3000','104,anu,Hr,hyderabad,4000']
total=0
for var in EMP:
    if('sales' in var):
        eid,ename,edept,ecity,ecost = var.split(",")
        print(f'Emp name:{ename.title()} Dept:{edept.upper()} City:{ecity.lower()}')
        total = total + int(ecost)

print("-"*45)
print(f"Sum of sales emp's cost is:{total}")
print("-"*45)
