'''
Write a python program:

EMP=[('101,raj,sales,Pune,1000','102,bibu,prod,bglore,2000'),
     ('103,leo,sales,Mumbai,3000','104,anu,Hr,hyderabad,4000')]

->display emp name ,working dept and city in below formats	  
	emp name in title case 
	emp working dept in uppercase 
	emp working city in lowercase
'''
EMP=[('101,raj,sales,Pune,1000','102,bibu,prod,bglore,2000'),
     ('103,leo,sales,Mumbai,3000','104,anu,Hr,hyderabad,4000')]

eid,ename,edept,ecity,ecost = EMP[0][0].split(",")
print(f"Emp name:{ename.title()} Dept:{edept.upper()} City:{ecity.lower()}")
eid,ename,edept,ecity,ecost = EMP[0][1].split(",")
print(f"Emp name:{ename.title()} Dept:{edept.upper()} City:{ecity.lower()}")

eid,ename,edept,ecity,ecost = EMP[1][0].split(",")
print(f"Emp name:{ename.title()} Dept:{edept.upper()} City:{ecity.lower()}")
eid,ename,edept,ecity,ecost = EMP[1][1].split(",")
print(f"Emp name:{ename.title()} Dept:{edept.upper()} City:{ecity.lower()}")

