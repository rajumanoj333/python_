def f1():
    L = []
    c=0
    while(c<5):
        f = input('Enter a filename:')
        L.append(f)
        c=c+1
    return L

def display(arg):
    print('List of files:-')
    for var in arg:
        print(var)

rv = f1()
display(rv)
print('Exit from main process')
