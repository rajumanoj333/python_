login = input('Enter a login name:')

if(login == 'root' or login == 'admin'):
    port = input('Enter a port number:')
    if(int(port) >500 and int(port)<600):
        app="TestApp"
    else:
        app="demoApp"
    print(f"App name is:{app} running port number is:{port}")
else:
    print('Sorry your login is not matched')
