device_name = input('Enter a device name:')

device_size = input(f'Enter a {device_name} size:')

device_cost = input(f'Enter a {device_name} cost:')

tax = float(device_cost) * 0.18
gs_total = float(device_cost) + tax

print(f'device name:{device_name},device_size:{device_size},
      device_cost:{device_cost},Tax:{tax},TotalValue:{gs_total}(Including tax)')
