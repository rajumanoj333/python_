Fname="network.cfg"
n=56
status=True
print(Fname,type(Fname))
print(n,type(n))
print(status,type(status))

n="device1"
print(n,type(n))

n=False
print(n,type(n))
