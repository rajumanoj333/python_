print('This is test code')

# single line comment

print(10+20) # addition
# print("Test1")
# print("Test2")
print('') # empty line
'''
this is multiline
comment section
'''
print('End of the line')
