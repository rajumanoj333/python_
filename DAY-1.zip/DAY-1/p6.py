'''
var_type='Ethernet'
UUID='HGTR4502'
vendor='cisco'
Cost=8933.23
status=False
'''
var_type = input('Enter a device type:')
UUID = input(f'Enter {var_type} UUID:')
vendor = input('Enter a vendor Name:')
Cost = input(f'Enter {var_type} Cost:')
status=input(f'Enter a {var_type} device working status:')

print(f'''About NIC attributes:-
--------------------------------
Type is {var_type}
-------------------
UUID Number is:{UUID}
-------------------------
Vendor Name is:{vendor}  Device Cost is:{Cost}
Device working status is:{status}
--------------------------------------------''')
