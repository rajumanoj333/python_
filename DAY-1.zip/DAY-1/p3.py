'''
Write a python program
 - display NIC attribute details
	- Type		(ex: ethernet)
	- UUID		(ex: SDF23432)
	- vendor	(ex: cisco)
	- version	(ex: 1.3)
	- Cost		(ex:4533.12)
	- device status (ex: True)

using single print() - display device details
'''
print('''About NIC attributes:-
--------------------------------
Type is ethernet
----------------
UUID Number is: SDF23432
--------------------------
Vendor Name is:cisco   Device Cost is:4590.32
Device working status is: True
--------------------------------------------''')
