var_type='Ethernet'
UUID='HGTR4502'
vendor='cisco'
Cost=8933.23
status=False

print(f'''About NIC attributes:-
--------------------------------
Type is {var_type}
----------------
UUID Number is:{UUID}
--------------------------
Vendor Name is:{vendor}  Device Cost is:{Cost}
Device working status is:{status}
--------------------------------------------''')
