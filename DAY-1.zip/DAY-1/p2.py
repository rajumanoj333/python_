# multiline string
print("data1\ndata2\ndata3")
print('') # empty line
'''
this is multiline
comment
'''
print('''DATA1
DATA2
DATA3''')
