pin=1234

c=0
while(c<3):
    c=c+1
    p = input('Enter a pinNumber:')
    if(int(p) == pin):
        print(f'Success - pin is matched - {c}')
        break

if(int(p) != pin):
    print('Sorry your pin is blocked')
