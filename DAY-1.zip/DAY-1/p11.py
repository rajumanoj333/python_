'''
>>> s='python'
>>> for var in s:
...     print(f'var value is:{var}')
...
var value is:p
var value is:y
var value is:t
var value is:h
var value is:o
var value is:n
>>>
'''
s='python'

i=0
while(i<len(s)):
    print(f'var value is:{s[i]}')
    i=i+1
