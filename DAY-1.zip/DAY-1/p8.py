port = input('Enter a port number:')

if(int(port) >500 and int(port)<600):
    app="TestApp"
else:
    app="demoApp"

print(f"App name is:{app} running port number is:{port}")
