log_number = input('Enter a lognumber:')

if(int(log_number) >15 and int(log_number)<20):
	event='info'
elif(int(log_number)>100 and int(log_number)<200):
	event='warn'
elif(int(log_number)>500 and int(log_number)<600):
	event='sys'
elif(int(log_number)>1000):
	event='critical'
else:
	print(f'Sorry lognumber {log_number} is not valid lognumber')
	exit() # exit from python process

print(f'LogNumber:{log_number} event name is:{event} log')
